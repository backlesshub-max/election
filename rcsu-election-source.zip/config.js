/* RCSU Election 2026-2027 | Configuration author: Reinhardson Sangma
 * Only the Supabase project URL and publishable/anon key belong here.
 * NEVER paste a Supabase secret/service_role key into this file.
 */
window.RCSU_CONFIG = Object.freeze({
  SUPABASE_URL: 'https://YOUR_PROJECT_REF.supabase.co',
  SUPABASE_PUBLISHABLE_KEY: 'YOUR_SUPABASE_PUBLISHABLE_KEY',
  EDGE_FUNCTION: 'election-api'
});
