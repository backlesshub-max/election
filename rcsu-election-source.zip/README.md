<!-- RCSU Student Union Election 2026–2027 | Project author: Reinhardson Sangma -->
# Raha College Student Union Election 2026–2027

A mobile-first, claymorphism-style election station for one administrator-operated laptop. The project uses HTML, CSS and vanilla JavaScript in the browser, a Supabase Edge Function for authenticated server operations, and PostgreSQL for eligibility checks and atomic anonymous ballot recording.

**Developer signature:** Reinhardson Sangma  
**Election:** Raha College Student Union Election 2026–2027  
**Deployment target:** GitHub Pages / Vercel + Supabase

> This repository was empty when work began. This is a new project scaffold. The website is not election-ready until a Supabase project is connected, the SQL migration and Edge Function are deployed, an administrator account is allow-listed, the voter workbook is imported, and the committee verifies candidate spellings and eligibility.

## What is included

- Claymorphism-inspired red, navy, white and gold election interface.
- Admin-only sign-in through Supabase Auth; there is no public sign-up.
- Single-device voter verification by exact full name, enrolment number or mobile number, with optional name/course clarification for duplicate matches.
- Sequential ballot for the nine posts shown on the supplied Assamese poster, translated to English.
- Nine separate candidate portraits cropped from the provided poster. Candidate records and images are editable by an administrator.
- Local temporary ballot progress, with no voter identity in `localStorage`; the short-lived ballot ticket is held in `sessionStorage`.
- Database-side one-vote enforcement, one choice per active post and anonymous aggregated results.
- Admin dashboard, pause/resume voting, candidate management, Excel import, search/filter, CSV export, print, results release and strong-confirmation reset.
- FormSubmit administrator email report containing aggregates only.
- Python CSV preflight utility that prints data-quality counts but never prints student PII.

## Election posts and poster candidates

The candidate names below are transliterations of the Assamese names on the poster. Please ask the election committee to confirm Roman spellings before voting opens.

| English position | Poster name (Roman transliteration) |
|---|---|
| President | Pallab Nath |
| Vice President | Ahikta Chahuma |
| General Secretary | Chaniya Chultana |
| Assistant General Secretary | Santosh Gaonkhoya |
| Games Secretary | Animesh Bora |
| Cultural Secretary | Puja Das |
| Magazine Secretary | Jubi Bora |
| Girls’ Common Room Secretary | Shivani Bangthai |
| Boys’ Common Room Secretary | Rupjyoti Gogoi |

The supplied poster shows one nominee for each post. The admin can add any additional candidate(s), including another President candidate, before polling starts.

## 1. Create and connect Supabase

1. Create a Supabase project in your organisation. Select a region close to Assam (Mumbai / `ap-south-1` is suitable).
2. In the Supabase SQL Editor, run the complete file `supabase/migrations/20261120_election_schema.sql`.
3. In **Authentication → Users**, create the election administrator user. Disable public sign-ups in Auth settings. Use a unique, strong password; do not use a six-digit shared password such as `787878` for a live election.
4. Copy the Auth user UUID and add that account to the private administrator allow-list in the SQL Editor:

   ```sql
   insert into election_private.admins(user_id)
   select id from auth.users where email = 'YOUR_ADMIN_EMAIL'
   on conflict (user_id) do nothing;
   ```

5. Copy the project URL and the **publishable** key (or legacy anon key) into `config.js`. Never use the Supabase secret or `service_role` key in `config.js` or any browser file.
6. Install the Supabase CLI, then link and deploy the server function:

   ```bash
   supabase login
   supabase link --project-ref YOUR_PROJECT_REF
   supabase functions deploy election-api
   ```

   The function is configured to require a valid JWT. Its server-side secret is supplied by the Supabase runtime; no service-role key is committed here.
7. In Supabase, run the Security Advisor after setup. The private `election_private` schema is not intended to be exposed through the Data API. All public RPC wrappers revoke execution from `anon` and `authenticated`; the Edge Function validates both the Supabase user and the private admin allow-list before using the server key.

## 2. Deploy the website

The GitHub repository stores the complete application source in `rcsu-election-source.zip`. A GitHub Actions workflow extracts the archive into the Pages deployment artifact whenever `main` is updated. In **Settings → Pages → Build and deployment**, select **GitHub Actions** as the source. After the workflow completes, the portal is published at the repository's GitHub Pages URL. For Vercel, download/extract `rcsu-election-source.zip` and import the extracted folder as a static project. Relative asset paths are used so the site works from a GitHub Pages project subpath.

Update `config.js` with:

```js
window.RCSU_CONFIG = Object.freeze({
  SUPABASE_URL: 'https://YOUR_PROJECT_REF.supabase.co',
  SUPABASE_PUBLISHABLE_KEY: 'YOUR_SUPABASE_PUBLISHABLE_KEY',
  EDGE_FUNCTION: 'election-api'
});
```

The publishable key is expected to be public; RLS, private-schema privileges, the Edge Function admin check and the server-side secret protect privileged data and actions.

## 3. Import the official voter workbook

1. Sign in with the allow-listed admin account.
2. Open **Import Voters** and select the supplied `.xlsx` workbook.
3. Confirm the preview, then import. The browser parses the workbook and sends records in batches of at most 300 through the authenticated Edge Function.
4. The workbook is not placed in this repository. Spreadsheet files and CSV files are ignored by `.gitignore`.

Expected headers are `SL No.`, `Name`, `Course / Class`, `Enrollment No.`, and `Mobile No.`. The importer retains records with missing enrolment/mobile values and does not print student data. It uses the physical worksheet row as a source reference because SL No. restarts across classes and is not globally unique. Re-importing the same workbook in the same order updates the same source references without resetting an existing `voting_status`.

### Voter workbook quality check

The attached workbook has **3,016 named voter records in 12 course/class groups**. The worksheet summary also totals 3,016.

| Course / class | Records |
|---|---:|
| BA 1st Sem | 973 |
| BA 3rd Sem | 445 |
| BA 5th Sem | 434 |
| BA 7th Sem | 78 |
| BCOM 1st Sem | 4 |
| BCOM 3rd Sem | 5 |
| BCOM 5th Sem | 6 |
| BSC 1st Sem | 44 |
| BSC 3rd Sem | 26 |
| BSC 5th Sem | 14 |
| HS 1st Year | 508 |
| HS 2nd Year | 479 |

Data-quality notes from the supplied workbook: 987 records have no enrolment number, 4 have no mobile number, three enrolment values are duplicated, 38 mobile values are duplicated, and 192 normalized name groups occur more than once. SL No. also repeats across class groups. All rows with names are retained. Ambiguous matches are rejected until the user supplies further identifying details; do not automatically select the first match.

Optional CSV audit (export the first worksheet as CSV from Excel first):

```bash
python tools/validate_voter_list.py path/to/Voter-Details.csv
```

The script reports aggregate completeness and duplicate counts only; it does not display student names, enrolment numbers or mobile numbers.

## 4. Candidate data and photos

Candidate rows are seeded by the SQL migration. Portrait files are in `assets/candidates/`. Administrators can change a candidate name, post, image path/URL, group and active status in **Manage Candidates**. Inactive candidates are not shown on the voting ballot. Add all competing candidates before voting opens and test the correct candidate-to-post mapping.

## 5. FormSubmit report

The admin dashboard sends an aggregate report to `rahacollegenss@gmail.com` through:

`https://formsubmit.co/ajax/rahacollegenss@gmail.com`

FormSubmit may require the recipient to activate the first email from its service. Check the mailbox and verify the integration with a test report before election day. The email is a convenience report, not the system of record. The database is the authoritative tally. The email payload does not contain voter identity or individual ballot selections.

## 6. Start the election

1. Confirm the candidate spellings, candidate photos, posts, and any additional contenders with the committee.
2. Import the voter register and confirm the eligible-voter total.
3. Sign in on the laptop that will operate the station.
4. Open the Admin Dashboard and switch **Accept voter sessions** on.
5. Choose **Open Voting Kiosk**. Students vote one at a time on this administrator-authenticated station.
6. After the voting period closes, pause voting. Authorise results release only when the committee approves.
7. Export/print the aggregate results and send the administrator email report.

The station clears the previous voter's visible name and temporary selections after **Finish**. The administrator session remains active so the next voter can proceed without re-entering the admin password. To leave kiosk mode, the administrator uses **Ctrl + Shift + A** and confirms the return to administrator sign-in. Keep the laptop physically supervised and do not leave the admin dashboard open to students.

## Ballot secrecy and security model

- Voter records and ballot rows live in a private Postgres schema with RLS enabled and no direct browser grants.
- All elevated operations pass through a JWT-protected Edge Function. It verifies the Supabase Auth user against `election_private.admins` before invoking server-only RPCs.
- Verification issues a random one-use ticket. Only a hash of that ticket is stored, temporarily linked to the voter record. On successful submission, the database transaction inserts the anonymous ballot rows, marks the voter as voted, and deletes the ticket-to-voter link. Ballot rows have no voter foreign key or voter identifier.
- The ballot write and duplicate-vote status update happen in one transaction. Reusing a ticket fails because the ticket is deleted.
- Student identity is held in application memory during the current kiosk session; local storage contains only temporary candidate selections and the current position index. Session storage holds only the opaque ticket.
- Candidate counts are aggregated for administration; individual ballots are never exposed by the UI or emailed. Winner badges are shown only after the results-release control is authorised.
- No Supabase secret/service-role key, voter workbook or voter records are included in this repository.

**Operational caveat:** database separation prevents a persistent voter-to-choice relationship in the application tables, but it cannot prevent a person physically watching the shared laptop from observing a student's selections. Provide a private screen angle and supervised, one-at-a-time voting. For a high-stakes legally regulated election, obtain an independent security review and use a purpose-built audited voting system.

## Languages and runtime

HTML, CSS and vanilla JavaScript run in the browser; TypeScript/Deno runs in Supabase Edge Functions; SQL enforces database integrity; Python is included for optional CSV preflight. Java and C++ are intentionally not included: GitHub Pages cannot execute them, and introducing separate runtimes would not improve this static-web-plus-Supabase architecture.

## Developer attribution and copying

Source files contain a developer signature for **Reinhardson Sangma**. The repository has an all-rights-reserved notice. A public GitHub repository can still be viewed, downloaded or forked; comments and signatures identify authorship but cannot technically prevent copying. Candidate portraits were cropped from the poster supplied for this project and are not licensed for unrelated use by this code notice.
